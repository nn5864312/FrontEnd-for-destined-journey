export { ResourceBar } from './ResourceBar';
