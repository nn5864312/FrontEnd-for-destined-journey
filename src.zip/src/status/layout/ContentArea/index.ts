export { ContentArea } from './ContentArea';
