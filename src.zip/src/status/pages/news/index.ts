export { NewsTab } from './NewsTab';
